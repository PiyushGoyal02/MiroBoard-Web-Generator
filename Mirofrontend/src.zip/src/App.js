import './App.css';
import { Route, Routes, useNavigate  } from 'react-router-dom';
import Payment from './Components/Payment';
import MedicalRecords from './Components/MedicalRecords';
import Register from './Components/Register';
import BookAppointment from './Components/BookAppointment';
import Homepage from './Components/Homepage';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useState, useEffect } from 'react';

function App() {

  const defineroutename = ["MedicalRecords", "Payment", "Register", "BookAppointment"]
  const navigator = useNavigate();
  const [FetchAPIData,SetAPIFetchData] = useState([])
  const [arrayroute, setarrayroute] = useState(defineroutename);
  const [zeroIndex, setZeroIndex] = useState(0);
  // const [html, setHTML] = useState({__html: ""});
  
  let contentArray = []
  useEffect(() => {
        const fetchData = async () => {
            try{
              const response = await axios.get('http://localhost:4000/fetch-data');
              console.log('SuccessFully Data Fetched:');
              // const value = (response.data)
              const value = response.data.data
              console.log(value)

              for(let i of value){
                // console.log(i.data.content,"IValue")
                contentArray.push(i.data.content)
              }
              console.log(contentArray)

              // const extractDataContent = value.map(arrayItem => arrayItem.data.content)
              // SetAPIFetchData(extractDataContent)




              // setHTMLvalue(value.content)
            } catch (error) {
                console.error('Error For Data Fetch:', error);
            }
        };
        fetchData();
  },[])




    const RouteComponents = {
      Payment: <Payment/>,
      Register: <Register/>,
      MedicalRecords: <MedicalRecords/>,
      BookAppointment: <BookAppointment/>
    }

    // const currentIndex =[zeroIndex + 1];
    // console.log(currentIndex, "currentIndex")
    // const hashNext = zeroIndex <= arrayroute.length - 1

    // const nextIndex = arrayroute[zeroIndex + 1];
    // setZeroIndex(nextIndex);
    
    function NextClickHandler(){
      if(zeroIndex <= arrayroute.length - 1){
        setZeroIndex(zeroIndex + 1)
        navigator(`/${arrayroute[zeroIndex]}`, {state : {arrayroute, zeroIndex}})
        console.log(arrayroute,"ArrayRoute");
      }
    }

    // function NextClickHandler() {
    //   if (zeroIndex < arrayroute.length - 1) {
    //     const newIndex = zeroIndex + 1;
    //     setZeroIndex(newIndex);
    //     const nextRoute = arrayroute[newIndex];
    //     navigator(`/${nextRoute}`, { state: { arrayroute, zeroIndex: newIndex }});
    //     console.log(arrayroute, "ArrayRoute");
    //   }
    // }
    

  return (
    <div>

      <div className="HomePageLinks">
        <Link to='/'>Home</Link>
        {arrayroute.map(route => (
          <Link key={route} to={`/${route.toLowerCase().replace(" ", "")}`}>{route}</Link>
        ))}
      </div>


      <div className='NextButtonDiv'>
          <button onClick={NextClickHandler} className='NextButton'>Next</button>
      </div>

      <Routes>
        <Route path='/' element={<Homepage />} />
        {arrayroute.map(route => (
          <Route key={route} path={`${route.toLowerCase().replace(" ", )}`} element={RouteComponents[route]} NextClickHandler={NextClickHandler} />
        ))}
      </Routes>

      <div>
        {
          FetchAPIData.map((content, index) => {
            <p key={index}>{content}</p>
          })
        }
      </div>


    </div>
  );
}

export default App;



