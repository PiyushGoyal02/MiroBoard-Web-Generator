// import { useNavigate, useLocation } from "react-router-dom";
function BookAppointment(){

    // const navigator = useNavigate();
    // const location = useLocation();

    // const { arrayroute } = location.state || {}

    // function ClickHandler(){
    //     navigator('/')
    // }
    return (
        <div>
            <p>Book Appointment</p>
            {/* <button onClick={ClickHandler}>Next</button> */}
        </div>
    )
}

export default BookAppointment;