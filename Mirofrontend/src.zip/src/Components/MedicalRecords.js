// import { useLocation, useNavigate } from "react-router-dom";



function MedicalRecords({NextClickHandler}){
    console.log(NextClickHandler)
    return (
        <div>
            <p>Medical Records</p>
            <button onClick={NextClickHandler}>Next</button>
        </div>
    )
}

export default MedicalRecords;