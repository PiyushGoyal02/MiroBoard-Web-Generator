import { useLocation, useNavigate } from "react-router-dom";

function Payment({NextClickHandler}){

    const navigator = useNavigate();
    const location = useLocation();

    const {arrayroute, zeroIndex} = location.state || {}

    function NextClickHandler(){
        navigator(`/${arrayroute[zeroIndex]}`)
    }

    return (
        
        <div>
            <div><button onClick={NextClickHandler}>Next Page</button></div>
            <div className="Payment-Container-Div">

                <div className="Payment-GateWay-TopDiv">

                    <div className="HealthCare-PatientInformation-Div">
                        <h1>Health Care Payment</h1>
                        <h3>Patient Information</h3>
                    </div>

                    <div className="Label-InputTag-MainDib">

                        <div className="InputLabelDiv">
                            <label className="Label-value" htmlFor="patient"> Patient Id:</label>
                            <input required  className="Input-Value" id="patient" type="text" placeholder="Enter Patient Id:"></input>
                        </div>

                        <div className="InputLabelDiv">
                            <label className="Label-value" htmlFor="patientname"> Patient Name:</label>
                            <input required  className="Input-Value" id="patientname" type="text" placeholder="Enter Patient Name"></input>
                        </div>

                        <div className="InputLabelDiv">
                            <label className="Label-value" htmlFor="drname"> Doctor Name</label>
                            <input required  className="Input-Value" id="drname" type="text" placeholder="Enter Dr.Name"></input>
                        </div>
                    </div>

                    <div>
                        <h2 className="HealthCare-Services">HealthCare Services Summary</h2>
                    </div>

                    <div className="Services-Payment">
                        <p>Consultation: $50</p>
                        <p>Lab Test: $100</p>
                        <p>Medication: $30</p>
                    </div>

                    <div>
                        <h2 className="Payment-Method">Payment Method</h2>
                    </div>

                    <div className="Submit-Button-MainDiv">
                        <button className="Submit-Button">Submit</button>
                    </div>

                </div>
            </div>
        </div>
    )
}

export default Payment;