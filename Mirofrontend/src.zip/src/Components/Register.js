import { useLocation, useNavigate } from "react-router-dom";



function Register({NextClickHandler}){

    const navigator = useNavigate();
    const location = useLocation();
    const {arrayroute, zeroIndex} = location.state || {};

    function NextClickHandler(){
        navigator(`/${arrayroute[zeroIndex]}`)
    }
    return (
        <div>
            <p>Register</p>
            <button onClick={NextClickHandler}>Next</button>
        </div>
    )
}

export default Register;